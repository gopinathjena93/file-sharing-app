const express = require('express');

const app = express();

const path = require('path');

app.set('view engine', 'ejs');

app.set('views',(path.join(__dirname,'views')));

PORT = process.env.PORT || 3000;

const connectDB = require('./config/db');
connectDB(); 

app.get("/",(req, res ) => {
	res.render('index');
})

app.use('/api/files', require('./routes/files'));





app.listen(PORT, () => {
	console.log(`Server listen at ${PORT}`);
})